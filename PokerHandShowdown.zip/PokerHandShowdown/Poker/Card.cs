﻿

namespace Poker
{
    public class Card : ICard
    {
        public RankType Rank { get; set; }
        public SuitType Suit { get;set; }
    }
}
