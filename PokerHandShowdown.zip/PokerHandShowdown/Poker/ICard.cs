﻿
namespace Poker
{
    public interface ICard
    {
        RankType Rank { get; set; }
        SuitType Suit { get; set; }

    }
 

}
